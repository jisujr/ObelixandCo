﻿namespace ObelixAndCo.Cells;

public class Forest : Cell
{
    public double mv { get; set; }

    public Forest()
    {
        mv = 1.0;
        _symbol = 'F';
    }

    public void DecreaseDensity()
    {
        mv -= 0.05;
        if (mv < 0) mv = 0;
    }
}
