﻿using ObelixAndCo.People;

namespace ObelixAndCo.Cells;

public class Hut : Cell
{
    private int love;

    public Hut()
    {
        love = 0;
        _symbol = 'H';
    }

    public bool isOccupied { get; set; }

    public void AddWorker(Person person)
    {
        if (love >= 5)
            throw new Exception("");

        love += 1;

        if (love == 5)
            IsOccupied = true;
    }

   
}
