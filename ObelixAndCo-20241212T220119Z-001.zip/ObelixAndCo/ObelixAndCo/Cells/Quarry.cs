﻿namespace ObelixAndCo.Cells;

public class Quarry : Cell
{
    public int lv { get; set; }

    public Quarry()
    {
        lv = 20;
        _symbol = 'Q';
    }

    public void Extract()
    {
        if (lv <= 0)
            throw new Exception("");
        
        lv -= 1;
    }
}
