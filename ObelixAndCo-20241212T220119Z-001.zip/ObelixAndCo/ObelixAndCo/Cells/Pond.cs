﻿namespace ObelixAndCo.Cells;

public class Pond : Cell
{
    public int op { get; }

    public Pond(int x, int y)
    {
        op = 5 * x + 5000 * y;
        _symbol = 'P';
    }
}
