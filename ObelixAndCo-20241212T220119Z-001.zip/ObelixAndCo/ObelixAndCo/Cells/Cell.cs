﻿namespace ObelixAndCo.Cells;

public class Cell
{
    public bool IsOccupied { get; set; }
    protected char _symbol;

    public char Symbol
    {
        get
        {
            char kyl;

            if (IsOccupied)
            {
                kyl = char.ToUpper(_symbol);
            }
            else
            {
                kyl = char.ToLower(_symbol);
            }

            return kyl;
        }
    }

    public Cell()
    {
        IsOccupied = false;
        _symbol = ' ';
    }
}

