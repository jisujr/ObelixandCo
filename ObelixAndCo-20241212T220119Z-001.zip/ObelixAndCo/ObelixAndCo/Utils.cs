﻿namespace ObelixAndCo;

public class Utils
{
    public class StringDistance
    {
        public static int LevenshteinDistance(string a, string b)
        {
            // Create a 2D array to store distances
            int[,] distance = new int[a.Length + 1, b.Length + 1];

            // Initialize the distance array
            for (int i = 0; i <= a.Length; i++)
                distance[i, 0] = i;
            for (int j = 0; j <= b.Length; j++)
                distance[0, j] = j;

            // Fill the array using the dynamic programming approach
            for (int i = 1; i <= a.Length; i++)
            {
                for (int j = 1; j <= b.Length; j++)
                {
                    // If characters match, no operation is needed
                    int cost = (a[i - 1] == b[j - 1]) ? 0 : 1;

                    // Take the minimum of the three operations: insert, delete, or substitute
                    distance[i, j] = Math.Min(
                        Math.Min(distance[i - 1, j] + 1,  // Deletion
                            distance[i, j - 1] + 1), // Insertion
                        distance[i - 1, j - 1] + cost);   // Substitution
                }
            }

            // The bottom-right corner of the matrix will have the Levenshtein distance
            return distance[a.Length, b.Length];
        }
    }

    
}