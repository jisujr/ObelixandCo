﻿using ObelixAndCo.Cells;

namespace ObelixAndCo.People;

public class Hunter : Person
{
    public Hunter(Cell cell) : base(cell)
    {
        // Vérification du type de cellule
        if (!(cell is Forest))
        {
            throw new ArgumentException("The cell was not a Forest");
        }
    }

    public bool Hunt()
    {
        if (Cell is Forest forest && forest.mv > 0)
        {
            forest.DecreaseDensity();
            return true;
        }

        return false;
    }
}