﻿using ObelixAndCo.Cells;

namespace ObelixAndCo.People;

public class Fisher : Person
{
    private Random _random;

    public Fisher(Cell cell) : base(cell)
    {
        if (!(cell is Pond))
        {
            throw new ArgumentException("The cell was not a pond");
        }

        _random = new Random(((Pond)cell).op);
    }

    public int Fish()
    {
        return _random.Next(0, 3); // Returns a random number between 0 and 2
    }
}
