﻿using ObelixAndCo;
using ObelixAndCo.Cells;
using ObelixAndCo.People;

//Console.WriteLine(new Cell().IsOccupied); // False
//Console.WriteLine(new Cell().Symbol); // ' '

/*var forest = new Forest();
Console.WriteLine(forest.Density); // 1
Console.WriteLine(forest.Symbol); // f
forest.IsOccupied = true;
Console.WriteLine(forest.Symbol); // F

var f = new Forest();
f.DecreaseDensity();
Console.WriteLine(f.Density); // 0.95
f.Density = 0.01;    // if we manually set the Density to 0.01
f.DecreaseDensity(); // this should not go below 0
Console.WriteLine(f.Density); // 0*/

//Console.WriteLine(new Quarry().Symbol); // q

/*Console.WriteLine(new Pond(1, 2).Symbol); // p
Console.WriteLine(new Pond(1, 2).op); // 10005*/

/*Console.WriteLine(new Hut().Symbol); // h
Console.WriteLine(new Hut().IsOccupied); // False*/

/*var hut = new Hut();
Console.WriteLine(hut.IsOccupied); // False
for (int i = 0; i < 5; i++)
    hut.AddWorker(); // we can add 5 workers
Console.WriteLine(hut.IsOccupied); // True
hut.AddWorker(); // throws an Exception*/



/*Cell cell = new Cell();
Console.WriteLine(cell.IsOccupied); // False
Person p = new Person(cell);
Console.WriteLine(cell.IsOccupied); // True*/


/*Fisher fisher = new Fisher(new Pond(0, 0));
Console.WriteLine(fisher.Fish()); // 2
Console.WriteLine(fisher.Fish()); // 2
Console.WriteLine(fisher.Fish()); // 2
Console.WriteLine(fisher.Fish()); // 1
Console.WriteLine(fisher.Fish()); // 0
Console.WriteLine(fisher.Fish()); // 1

Cell cell = new Pond(1, 1);
Fisher fisher2 = new Fisher(cell);
// Console.WriteLine(fisher2._random.Next()); // 998452736
Console.WriteLine(fisher2.Fish()); // 1 (or 0 if you uncomment the line above)*/



/*Hunter hunter1 = new Hunter(new Forest()); // OK*/


//Grid gameGrid = new Grid(5, 30, 100);
//Console.WriteLine(gameGrid.ToString());

/*Grid gameGrid = new Grid(5, 5, 100);
Hut? freeHut = gameGrid.FindFreeHut(); // null

gameGrid.Cells[0][0] = new Hut();
Hut? maybeAnHut = gameGrid.FindFreeHut(); // == gameGrid.Cells[0][0]


gameGrid.Cells[0][0] = new Quarry();
gameGrid.Cells[0][3] = new Hut();
gameGrid.Cells[3][0] = new Hut();
Hut? andNowAnHut = gameGrid.FindFreeHut(); // == gameGrid.Cells[0][3]*/



/*Grid gameGrid = new Grid(5, 30, 100);
gameGrid.Cells[1][1] = new Forest();
Hunter hunter = new Hunter(gameGrid.Cells[1][1]);
bool added = gameGrid.AddPerson(hunter);
Console.WriteLine(added); // False
Console.WriteLine(gameGrid.People.Count); // 0

Hut hut1 = new Hut();
Hut hut2 = new Hut();
gameGrid.Cells[0][1] = hut1;
gameGrid.Cells[1][0] = hut2;
gameGrid.Cells[3][0] = new Quarry();
added = gameGrid.AddPerson(new Sculptor(gameGrid.Cells[3][0]));
Console.WriteLine(added); // True
Console.WriteLine(gameGrid.People.Count); // 1
Console.WriteLine(hut1.IsOccupied); // False
Console.WriteLine(hut2.IsOccupied); // False

for (int i = 0; i < 4; i++)
{
    added = gameGrid.AddPerson(new Hunter(new Forest()));
}
Console.WriteLine(added);  // True
Console.WriteLine(gameGrid.People.Count); // 5
Console.WriteLine(hut1.IsOccupied); // True
Console.WriteLine(hut2.IsOccupied); // False*/


/*Grid gameGrid = new Grid(5, 30, 100);
gameGrid.Cells[2][2] = new Pond(2, 2);
gameGrid.Cells[1][1] = new Hut();
for (int x = 0; x < 5; x++)
{
    for (int y = 20; y < 30; y++)
    {
        gameGrid.Cells[x][y] = new Forest();
    }
}
gameGrid.Cells[0][0] = new Quarry();
gameGrid.AddPerson(new Sculptor(gameGrid.Cells[0][0]));
gameGrid.AddPerson(new Hunter(gameGrid.Cells[0][20]));
Console.WriteLine(gameGrid.ToString());

gameGrid.NextTurn();
Console.WriteLine(gameGrid.ToString());*/

/*Grid gameGrid = new Grid(5, 30, 100);
gameGrid.Wallet = 1000;
gameGrid.Buy(2, 2, "pond"); // True
gameGrid.Buy(1, 1, "hut"); // True
for (int x = 0; x < 5; x++)
{
    for (int y = 20; y < 30; y++)
    {
        gameGrid.Buy(x, y, "forest"); // True
    }
}
gameGrid.Buy(0, 0, "quarry"); // True
gameGrid.Buy(0, 0, "sculptor"); // True
gameGrid.Buy(0, 20, "hunter"); // True
Console.WriteLine(gameGrid.ToString());*/

/*Grid gameGrid = new Grid(5, 30, 100);
Console.Write(gameGrid.ShowMenu()); // "buy/sell/next/exit"*/

/*Grid gameGrid = new Grid(5, 30, 100);
Console.Write(gameGrid.DisplayEnd()); // GAME OVER
gameGrid.Wallet = 1000;
Console.Write(gameGrid.DisplayEnd()); // WIN*/
/*RandomPrice randomPrice = new(100, 0.05);

Console.WriteLine(randomPrice.GetMenhirPrice(1)); // 100
Console.WriteLine(randomPrice.GetMenhirPrice(2)); // 105
Console.WriteLine(randomPrice.GetMenhirPrice(3)); // 118
Console.WriteLine(randomPrice.GetMenhirPrice(4)); // 120
*/


