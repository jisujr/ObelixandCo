﻿using System.Text;
using ObelixAndCo.Cells;
using ObelixAndCo.People;

namespace ObelixAndCo;

public class Grid
{
    public Cell[][] Cells;
    public int Wallet;
    public int Food;
    public int Menhirs;
    private int _objective;
    private int _currentTurn;
    public List<Person> People;

    // Grid fun teri ma

    public Grid(int rows, int cols, int objective)
    {
        Cells = new Cell[rows][];
        for (int j = 0; j < rows; j++)
        {
            Cells[j] = new Cell[cols];
            for (int i = 0; i < cols; i++)
            {
                Cells[j][i] = new Cell();
            }
        }

        Wallet = 0;
        Food = 0;
        Menhirs = 0;
        _objective = objective;
        _currentTurn = 0;
        People = new List<Person>();
    }

    //To sTring fun 

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Cells[0].Length + 2; i++)
        {
            sb.Append("-");
        }

        sb.AppendLine();

        for (int i = 0; i < Cells.Length; i++)
        {
            sb.Append("|");
            for (int j = 0; j < Cells[i].Length; j++)
            {
                Cell cell = Cells[i][j];
                sb.Append(cell.Symbol);
            }

            sb.AppendLine("|");
        }

        for (int i = 0; i < Cells[0].Length + 2; i++)
        {
            sb.Append("-");
        }

        sb.AppendLine();
        sb.AppendLine($"Money: {Wallet} Sestertius");
        sb.AppendLine($"Menhirs: {Menhirs}");
        sb.AppendLine($"Food: {Food}");
        sb.AppendLine($"Turn: {_currentTurn}");

        return sb.ToString();
    }
    
    //FindFreeHut fun 
    
    public Hut FindFreeHut()
    {
        for (int i = 0; i < Cells.Length; i++)
        {
            for (int j = 0; j < Cells[i].Length; j++)
            {
                if (Cells[i][j] is Hut pv && pv.isOccupied == false) 
                {
                    return pv; 
                }
            }
        }
        return null; 
    }
    
    
    //Add Person Fun
    public bool AddPerson(Person person)
    {
        foreach (var mv in Cells)
        {
            foreach (var ls in mv)
            {
                if (ls is Hut hut)
                {
                    if (hut.IsOccupied == false)
                    {
                        People.Add(person);
                        hut.AddWorker(person);
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    //public void Next fun 
    
    public void NextTurn()
    {
        foreach (var a in People)
        {
            if (a is Hunter x)
            {
                if (x.Hunt()) 
                {
                    Food = Food + 1;  
                }
            }
            else if (a is Sculptor y)
            {
                y.Sculpt(); 
                Menhirs = Menhirs + 1;  
            }
            else if (a is Fisher z)
            {
                int farrlafish = z.Fish(); 
                Food = Food + farrlafish;  
            }
        }

        _currentTurn++; 
    }
    
    //Buy Function Revenir sur cette fonction 
   
    public bool Buy(int x, int y, string item)
    {
        if (x < 0 || y < 0 || x >= Cells.Length || y >= Cells[0].Length)
            return false; // Out of bounds

        item = item.ToLower();

        // Check if the item is a cell type
        if (item == "pond")
        {
            Cells[x][y] = new Pond(x, y);
            return true;
        }
        else if (item == "hut")
        {
            Cells[x][y] = new Hut();
            return true;
        }
        else if (item == "forest")
        {
            Cells[x][y] = new Forest();
            return true;
        }
        else if (item == "quarry")
        {
            Cells[x][y] = new Quarry();
            return true;
        }

        // Check if the item is a person type and add to the corresponding cell type
        if (item == "sculptor" && Cells[x][y] is Quarry)
        {
            AddPerson(new Sculptor(Cells[x][y]));
            return true;
        }
        else if (item == "hunter" && Cells[x][y] is Forest)
        {
            AddPerson(new Hunter(Cells[x][y]));
            return true;
        }
        else if (item == "fisher" && Cells[x][y] is Pond)
        {
            AddPerson(new Fisher(Cells[x][y]));
            return true;
        }

        return false;
    }
    //Sell Fun
    
    public bool Sell(int menhirs)
    {
        if (menhirs <= 0 || menhirs > Menhirs)
        {
            return false;
        }
        Menhirs = Menhirs - menhirs;
        return true;
    }
//Show menu 

    public string ShowMenu()
    {
        return "buy/sell/next/exit";
    }

    //public string DisplayEnd fun  don't work 
    
    public string DisplayEnd()
    {
        if (Wallet >= 1000)
        {
            return "WIN";
        }
        else
        {
            return "GAME OVER";
        }
    }
    // handlebuy fun

}


    
        
    
    
    
    