﻿namespace ObelixAndCo;

public class RandomPrice
{
    private int _basePrice;
    private double _inflationRate;
    private Random _random;

    public RandomPrice(int basePrice, double inflationRate)
    {
        _basePrice = basePrice;
        _inflationRate = inflationRate;
        _random = new Random(12345);
    }
    public int GetMenhirPrice(int currentTurn)
    {
        double p = _basePrice * (1 + _inflationRate * currentTurn);
        
        int r = _random.Next(-50, 51); 
        double f = p * r / 1000.0; 

        double t = p + f;
        return (int)t;
    }
}

